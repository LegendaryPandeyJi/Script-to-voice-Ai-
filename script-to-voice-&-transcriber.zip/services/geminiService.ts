import { GoogleGenAI, Modality, VoiceName, LiveSession, LiveServerMessage } from '@google/genai';
import { createPcmBlob } from '../utils/audioUtils';

let ai: GoogleGenAI;
const getAi = () => {
    if (!ai) {
        if (!process.env.API_KEY) {
            throw new Error("API_KEY environment variable not set");
        }
        ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return ai;
};

export const generateSpeech = async (script: string, voice: VoiceName): Promise<string> => {
    try {
        const aiInstance = getAi();
        const response = await aiInstance.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: script }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voice },
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("No audio data received from API.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Error generating speech:", error);
        throw error;
    }
};

export const startTranscriptionSession = async (
    onTranscriptionUpdate: (text: string, isFinal: boolean) => void,
): Promise<{ sessionPromise: Promise<LiveSession>; stream: MediaStream; audioContext: AudioContext; scriptProcessor: ScriptProcessorNode }> => {
    
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    // FIX: Cast window to `any` to support `webkitAudioContext` for broader browser compatibility, resolving the TypeScript error.
    const audioContext = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    const source = audioContext.createMediaStreamSource(stream);
    const scriptProcessor = audioContext.createScriptProcessor(4096, 1, 1);

    let currentTranscription = "";

    const sessionPromise = getAi().live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
            onopen: () => {
                console.log('Live session opened.');
                scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                    const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                    const pcmBlob = createPcmBlob(inputData);
                    sessionPromise.then((session) => {
                        session.sendRealtimeInput({ media: pcmBlob });
                    }).catch(err => console.error("Error sending audio data:", err));
                };
                source.connect(scriptProcessor);
                scriptProcessor.connect(audioContext.destination);
            },
            onmessage: (message: LiveServerMessage) => {
                if (message.serverContent?.inputTranscription) {
                    const { text } = message.serverContent.inputTranscription;
                    currentTranscription += text;
                    onTranscriptionUpdate(currentTranscription, false);
                }
                 if (message.serverContent?.turnComplete) {
                    onTranscriptionUpdate(currentTranscription, true);
                    currentTranscription = "";
                 }
            },
            onerror: (e: ErrorEvent) => {
                console.error('Live session error:', e);
            },
            onclose: (e: CloseEvent) => {
                console.log('Live session closed.');
            },
        },
        config: {
            // FIX: Added `responseModalities` as it's required by the Live API guidelines, even for transcription-only use cases.
            responseModalities: [Modality.AUDIO],
            inputAudioTranscription: {},
        },
    });

    return { sessionPromise, stream, audioContext, scriptProcessor };
};
