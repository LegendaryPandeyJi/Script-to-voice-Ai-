
import React, { useState, useRef } from 'react';
import { startTranscriptionSession } from '../services/geminiService';
import { LiveSession } from '@google/genai';
import MicIcon from './icons/MicIcon';
import StopIcon from './icons/StopIcon';

const TranscriptionSection: React.FC = () => {
    const [isRecording, setIsRecording] = useState(false);
    const [transcription, setTranscription] = useState('');
    const [error, setError] = useState<string | null>(null);

    const sessionRef = useRef<LiveSession | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);

    const handleTranscriptionUpdate = (text: string, isFinal: boolean) => {
        setTranscription(text);
    };

    const startRecording = async () => {
        if (isRecording) return;
        setError(null);
        setTranscription('');
        setIsRecording(true);
        try {
            const { sessionPromise, stream, audioContext, scriptProcessor } = await startTranscriptionSession(handleTranscriptionUpdate);
            
            streamRef.current = stream;
            audioContextRef.current = audioContext;
            scriptProcessorRef.current = scriptProcessor;

            const session = await sessionPromise;
            sessionRef.current = session;

        } catch (err) {
            console.error("Failed to start recording session:", err);
            setError("Could not start recording. Please ensure you have given microphone permissions.");
            setIsRecording(false);
        }
    };
    
    const stopRecording = () => {
        if (!isRecording) return;
        setIsRecording(false);
        
        sessionRef.current?.close();
        
        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }

        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }

        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }

        sessionRef.current = null;
    };

    return (
        <div className="bg-dark-card rounded-xl shadow-lg p-6 flex flex-col h-full border border-dark-border">
            <h2 className="text-2xl font-bold mb-4 text-brand-primary">Voice to Script</h2>
            <div className="flex-grow bg-dark-bg p-4 rounded-lg border border-dark-border min-h-[150px] overflow-y-auto">
                <p className="whitespace-pre-wrap">
                    {transcription || <span className="text-dark-subtext">Your transcribed text will appear here...</span>}
                </p>
                {isRecording && <div className="animate-pulse h-2 w-2 bg-brand-danger rounded-full inline-block ml-2"></div>}
            </div>
            <div className="mt-4">
                 {error && <p className="text-brand-danger mb-2 text-center">{error}</p>}
                {!isRecording ? (
                    <button
                        onClick={startRecording}
                        className="w-full bg-brand-primary hover:bg-opacity-80 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition-all duration-300 transform hover:scale-105"
                    >
                        <MicIcon />
                        Start Recording
                    </button>
                ) : (
                    <button
                        onClick={stopRecording}
                        className="w-full bg-brand-danger hover:bg-opacity-80 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition-all duration-300 transform hover:scale-105"
                    >
                        <StopIcon />
                        Stop Recording
                    </button>
                )}
            </div>
        </div>
    );
};

export default TranscriptionSection;
