import React, { useState } from 'react';
import { generateSpeech } from '../services/geminiService';
import { VoiceName } from '../types';
import { AVAILABLE_VOICES } from '../constants';
import { decode } from '../utils/audioUtils';
import Spinner from './Spinner';

// FIX: Add helper functions to create a valid WAV file from raw PCM audio data.
// This is necessary because the browser's <audio> element cannot play raw PCM directly.
// By wrapping it in a WAV container, we can make it playable without major UI changes.

/**
 * Writes a string to a DataView.
 * @param {DataView} view The DataView to write to.
 * @param {number} offset The offset to start writing at.
 * @param {string} string The string to write.
 */
function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

/**
 * Creates a WAV file Blob from raw PCM data.
 * @param {Uint8Array} pcmData The raw PCM data.
 * @param {number} sampleRate The sample rate of the audio.
 * @param {number} numChannels The number of channels.
 * @param {number} bitsPerSample The number of bits per sample.
 * @returns {Blob} A Blob representing the WAV file.
 */
function createWavBlob(pcmData: Uint8Array, sampleRate: number, numChannels: number, bitsPerSample: number): Blob {
  const byteRate = sampleRate * numChannels * (bitsPerSample / 8);
  const blockAlign = numChannels * (bitsPerSample / 8);
  const dataSize = pcmData.length;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  // RIFF header
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(view, 8, 'WAVE');

  // "fmt " sub-chunk
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);

  // "data" sub-chunk
  writeString(view, 36, 'data');
  view.setUint32(40, dataSize, true);

  // Write PCM data
  for (let i = 0; i < dataSize; i++) {
    view.setUint8(44 + i, pcmData[i]);
  }

  return new Blob([view], { type: 'audio/wav' });
}

const TtsSection: React.FC = () => {
  const [script, setScript] = useState('Hello there! Welcome to the AI Voice Studio. You can type any script here and I will read it for you.');
  const [voice, setVoice] = useState<VoiceName>(VoiceName.Kore);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const handleGenerateSpeech = async () => {
    if (!script.trim()) {
      setError('Script cannot be empty.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAudioUrl(null);

    try {
      const base64Audio = await generateSpeech(script, voice);
      const audioBytes = decode(base64Audio);
      // FIX: Incorrectly creating a blob with 'audio/mpeg' type for raw PCM data.
      // The API returns raw PCM audio, which must be wrapped in a proper container (like WAV) to be played.
      // Switched to using the `createWavBlob` helper to generate a playable audio file.
      // The TTS audio is 16-bit PCM, 24kHz, 1 channel.
      const blob = createWavBlob(audioBytes, 24000, 1, 16);
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
    } catch (err) {
      setError('Failed to generate audio. Please check your API key and try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-dark-card rounded-xl shadow-lg p-6 flex flex-col h-full border border-dark-border">
      <h2 className="text-2xl font-bold mb-4 text-brand-secondary">Script to Voice</h2>
      <div className="flex-grow flex flex-col space-y-4">
        <textarea
          value={script}
          onChange={(e) => setScript(e.target.value)}
          placeholder="Enter your script here..."
          className="w-full flex-grow p-3 bg-dark-bg border border-dark-border rounded-lg resize-none focus:ring-2 focus:ring-brand-secondary focus:outline-none transition"
          rows={8}
        />
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-grow">
            <label htmlFor="voice-select" className="block text-sm font-medium text-dark-subtext mb-1">
              Select Voice
            </label>
            <select
              id="voice-select"
              value={voice}
              onChange={(e) => setVoice(e.target.value as VoiceName)}
              className="w-full p-3 bg-dark-bg border border-dark-border rounded-lg focus:ring-2 focus:ring-brand-secondary focus:outline-none transition"
            >
              {AVAILABLE_VOICES.map((v) => (
                <option key={v.value} value={v.value}>{v.name}</option>
              ))}
            </select>
          </div>
          <div className="self-end sm:self-center w-full sm:w-auto">
             <button
                onClick={handleGenerateSpeech}
                disabled={isLoading}
                className="w-full sm:w-auto mt-4 sm:mt-0 bg-brand-secondary hover:bg-opacity-80 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center transition-all duration-300 transform hover:scale-105"
            >
                {isLoading ? <Spinner /> : 'Generate Audio'}
            </button>
          </div>
        </div>
        
        {error && <p className="text-brand-danger mt-2">{error}</p>}

        {audioUrl && (
          <div className="mt-4">
            <audio controls src={audioUrl} className="w-full" />
          </div>
        )}
      </div>
    </div>
  );
};

export default TtsSection;
