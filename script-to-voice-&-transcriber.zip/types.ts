
export enum VoiceName {
  Kore = 'Kore',
  Puck = 'Puck',
  Zephyr = 'Zephyr',
  Charon = 'Charon',
  Fenrir = 'Fenrir',
}
